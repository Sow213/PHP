<?php

function checkLogin($login, $password)
{
    $url = "http://localhost/Projet%20PHP/api/check_login";
    $data = http_build_query(['login' => $login, 'password' => $password]);

    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => $data,
            'timeout' => 5 // Ajout d'un timeout pour éviter les blocages
        ]
    ];

    $context = stream_context_create($options);
    $result = @file_get_contents($url, false, $context);

    // Vérifie si la requête a échoué
    if ($result === false) {
        return ['error' => 'Impossible de contacter l\'API'];
    }

    $response = json_decode($result, true);

    // Vérifie si la réponse est bien formatée
    if (!is_array($response) || !isset($response['status'])) {
        return ['error' => 'Réponse invalide de l\'API'];
    }

    return $response['status'] === 'success';
}

?>
