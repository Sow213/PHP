<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">


<style>
body {
    background: linear-gradient(to bottom right, #0d1b2a, #1b263b, #415a77); /* Dégradé fluide */
    color: white;
    font-family: 'Poppins', sans-serif; /* Police moderne */
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

/* Conteneur principal */
.container {
    width: 90%;
    max-width: 400px;
}

/* Cartes avec effet Glassmorphism */
.card {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    padding: 20px;
    text-align: center;
}

/* Champs de formulaire */
.form-control {
    background: rgba(255, 255, 255, 0.15);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
    padding: 10px;
    border-radius: 8px;
    transition: all 0.3s ease-in-out;
}

/* Effet lorsqu'on clique sur le champ */
.form-control:focus {
    background: rgba(255, 255, 255, 0.25);
    border-color: rgba(255, 255, 255, 0.6);
    outline: none;
}

/* Boutons modernisés */
.btn-primary {
    background: linear-gradient(135deg, #1e90ff, #007bff);
    border: none;
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.3s ease-in-out;
}

/* Effet au survol */
.btn-primary:hover {
    background: linear-gradient(135deg, #007bff, #0056b3);
    transform: scale(1.05);
}

/* Ajout d’une légère animation au bouton */
.btn-primary:active {
    transform: scale(0.95);
}

.logo-container {
    text-align: center;
    margin-bottom: 20px;
}

.logo-container img {
    width: 120px; /* Ajuste selon la taille du logo */
    height: auto;
    filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.3)); /* Effet d'ombre légère */
}

</style>
</head>
<body>

<div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
    <div class="card" style="width: 400px;">
        <div class="card-body">
            <div class="logo-container">
    <img src="images/logoGSB.png" alt="Logo GSB">
</div>

            <h1 class="card-title text-center">Login</h1>
                <?php if(isset($_SESSION['message'])): ?>
                    <div class="alert alert-danger"><?php echo $_SESSION['message']; ?></div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>
            
            <form method="POST" action="index.php?action=LG">
                <div class="form-group">
                    <label for="username">Email</label>
                    <input type="text" class="form-control" id="username" name="username">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password">
                </div>
                <button type="submit" class="btn btn-primary btn-block">Login</button>
            </form>
        </div>
    </div>
</div>

</body>

</html>
