<?php
// Inclure les modèles et contrôleurs nécessaires
require_once "Modele/modeleMedoc.php";
require_once "Controleur/controleur.php";

// Vérifier l'action dans l'URL et exécuter la fonction correspondante
if (!empty($_GET["action"])) {
    $action = $_GET["action"];
    
    if ($action === "LG" && !empty($_POST["username"]) && !empty($_POST["password"])) {
        loginUser($_POST["username"], $_POST["password"]);
    } elseif ($action === "LO") {
        logoutUser();
    } elseif ($action === "DET" && !empty($_POST['id_medicament'])) {
        details($_POST['id_medicament']);
    } elseif ($action === "REJ") {
        rejoindreAct();
    } elseif ($action === "CO") {
        conferences();
    } elseif ($action === "JU") {
        juridique();
    } elseif ($action === "CH") {
        chercheurs();
    } else {
        displayMedocs();
    }
} else {
    displayMedocs();
}
?>