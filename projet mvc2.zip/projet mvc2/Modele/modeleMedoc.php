<?php

function checkLogin($login, $password)
{
    // URL de l'API pour vérifier les informations de connexion
    $url = "http://localhost/phpgroupe/api/check_login";
    
    // Les données envoyées à l'API
    $data = array('login' => $login, 'password' => $password);
    
    // Configuration de la requête POST
    $options = array(
        'http' => array(
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data)
        )
    );
    
    // Créer un contexte de stream pour effectuer la requête
    $context = stream_context_create($options);
    
    // Effectuer la requête HTTP
    $result = file_get_contents($url, false, $context);
    
    // Décoder la réponse JSON
    $response = json_decode($result, true);
    
    // Vérifier la réponse de l'API pour savoir si l'utilisateur existe
    if (isset($response['status']) && $response['status'] == 'success') {
        // Si l'authentification est réussie, retourner true
        return true;
    } else {
        // Si l'authentification échoue, retourner false
        return false;
    }
}

// Fonction pour récupérer les données de l'utilisateur (par exemple, lors de la connexion)
function getUserData($login)
{
    // URL de l'API pour récupérer les informations de l'utilisateur
    $url = "http://localhost/phpgroupe/api/user_data?login=" . urlencode($login);
    
    // Effectuer la requête pour récupérer les données
    $user_json = file_get_contents($url);
    
    // Décoder la réponse JSON
    $user_data = json_decode($user_json, true);
    
    // Retourner les données de l'utilisateur
    return $user_data;
}

?>
