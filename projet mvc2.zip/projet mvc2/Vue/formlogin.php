<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Connexion</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background-color: #1c1c68;
            color: #FFFFFF;
        }
        .container {
            max-width: 400px;
            margin-top: 100px;
        }
        .card {
            background-color: #000000;
            border: 1px solid #87cb28;
            color: #FFFFFF;
        }
        .btn-custom {
            background-color: #c61e18;
            color: #FFFFFF;
        }
        .btn-custom:hover {
            background-color: #87cb28;
            color: #000000;
        }
        .logo {
            display: block;
            margin: 0 auto 10px;
            max-width: 200px;
            margin-bottom: -20px;
        }
    </style>
</head>
<body class="bg-[#1c1c68] text-white flex items-center justify-center min-h-screen">

    <div class="w-full max-w-md p-6 bg-black border border-[#87cb28] shadow-lg rounded-lg">
        <img src="https://image.noelshack.com/fichiers/2025/12/4/1742463911-logo-gsb-removebg-preview.png" alt="Logo GSB" class="mx-auto mb-4 w-32">
        <h2 class="text-center text-2xl font-semibold mb-4">Connexion</h2>
        
        <form action="controleur/connexion.php" method="POST" class="space-y-4">
            <div>
                <label for="nomUtilisateur" class="block text-sm font-medium">Nom d'utilisateur</label>
                <input type="text" id="nomUtilisateur" name="nomUtilisateur" required
                    class="w-full px-3 py-2 border rounded-md bg-white text-black focus:ring-[#87cb28] focus:border-[#87cb28]">
            </div>

            <div>
                <label for="motDePasse" class="block text-sm font-medium">Mot de passe</label>
                <input type="password" id="motDePasse" name="motDePasse" required
                    class="w-full px-3 py-2 border rounded-md bg-white text-black focus:ring-[#87cb28] focus:border-[#87cb28]">
            </div>

            <button type="submit"
                class="w-full bg-[#c61e18] hover:bg-[#87cb28] text-white font-semibold py-2 rounded-md transition">
                Se connecter
            </button>
        </form>
    </div>

</body>
</html>
