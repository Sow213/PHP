<?php 
// Vérifier si la variable est définie avant de l'utiliser
if (!isset($medicaments)) {
    $medicaments = []; // Valeur par défaut vide si pas de médocs
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <title>Liste des médicaments de GSB</title>
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        /* CSS personnalisé pour le logo */
        .logo {
            width: 80px; /* Taille du logo ajustée */
            height: auto;
            margin-right: 0px; /* Marge à droite du logo pour l'espacement avec le menu */
        }

        /* Centrer le menu tout en gardant le logo à gauche */
        .nav-container {
            display: flex;
            align-items: center; /* Alignement vertical */
            justify-content: center; /* Centrer les éléments horizontalement */
            flex-grow: 1; /* Laisser de l'espace pour centrer */
        }

        .nav-links {
            display: flex;
            justify-content: center;
            gap: 40px; /* Espacement entre les éléments du menu */
        }

        /* Taille du texte du menu et changement de couleur */
        .nav-links a {
            font-size: 20px; /* Agrandir la taille du texte */
            font-weight: bold; /* Mettre le texte en gras */
            text-transform: uppercase; /* Mettre les liens en majuscules */
            transition: color 0.3s ease; /* Animation douce pour la couleur */
        }

        /* Changer la couleur au survol */
        .nav-links a:hover {
            color: #14144f;
        }
    </style>

    <!-- Menu de navigation -->
    <header class="bg-[#1C1C68] p-4 text-white flex">
        <!-- Logo à gauche -->
        <img src="https://image.noelshack.com/fichiers/2025/12/4/1742462516-logo-gsb.png" alt="Logo GSB" class="logo">
        
        <!-- Conteneur pour centrer le menu -->
        <div class="nav-container">
            <nav class="nav-links">
                <!-- Liens du menu -->
                <a href="DetailsMedicaments.php" class="hover:text-[#14144f] transition">Médicaments</a>
                <a href="activites.php" class="hover:text-[#14144f] transition">Activités</a>
                <a href="juridique.php" class="hover:text-[#14144f] transition">Mentions Légales</a>

            </nav>
        </div>
    </header>

</head>

<body class="bg-gray-100 min-h-screen flex flex-col">

    <main class="flex-grow container mx-auto py-10">
        <h1 class="text-3xl font-bold text-[#1C1C68] mb-8 text-center">Liste des médicaments de GSB</h1>

        <div class="overflow-x-auto shadow-md rounded-lg bg-white p-6">
            <table class="min-w-full border border-gray-300 text-center">
                <thead class="bg-[#1C1C68] text-white">
                    <tr>
                        <th class="py-3 px-4 border-b">ID</th>
                        <th class="py-3 px-4 border-b">Nom</th>
                        <th class="py-3 px-4 border-b">Description</th> 
                        <th class="py-3 px-4 border-b">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($medicaments) > 0): ?>
                        <?php foreach ($medicaments as $medoc): ?>
                            <tr class="hover:bg-gray-100">
                                <td class="py-2 px-4 border-b"><?php echo htmlspecialchars($medoc["id"]); ?></td>
                                <td class="py-2 px-4 border-b"><?php echo htmlspecialchars($medoc["nom"]); ?></td>
                                <td class="py-2 px-4 border-b"><?php echo htmlspecialchars($medoc["description"]); ?></td> <!-- Affichage de la description -->
                                <td class="py-2 px-4 border-b">
                                    <form method="post" action="index.php?action=DET">
                                        <input type="hidden" name="id_medicament" value="<?php echo htmlspecialchars($medoc["id"]); ?>">
                                        <button type="submit" name="details" value="Details"
                                            class="bg-[#1C1C68] text-white px-4 py-2 rounded hover:bg-[#14144f] transition">
                                            Détails
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="py-4">Aucun médicament trouvé.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Retiré la ligne include du pied de page -->

</body>
</html>
