<?php
// Inclure les modèles et contrôleurs nécessaires
require_once "Modele/modeleMedoc.php";
require_once "Controleur/controleur.php";

// Démarrer la session (si ce n'est pas déjà fait)
session_start();

// Vérifier l'action dans l'URL et appeler la fonction appropriée
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Utilisation d'un switch pour la gestion des actions
switch ($action) {
    case 'LG':
        // Login de l'utilisateur
        if (isset($_POST["username"]) && isset($_POST["password"])) {
            $login = $_POST["username"];
            $password = $_POST["password"];
            loginUser($login, $password);
        }
        break;

    case 'LO':
        // Logout de l'utilisateur
        logoutUser();
        break;

    case 'DET':
        // Détails du médicament
        if (isset($_POST['id_medicament'])) {
            $id_medicament = $_POST['id_medicament'];
            details($id_medicament);
        }
        break;

    case 'REJ':
        // Rejoindre une conférence
        rejoindreAct();
        break;

    case 'CO':
        // Affichage des conférences
        conferences();
        break;

    case 'JU':
        // Mentions légales
        juridique();
        break;

    case 'CH':
        // Chercheurs
        chercheurs();
        break;

    default:
        // Page par défaut : Médicaments
        displayMedocs();
        break;
}
?>
