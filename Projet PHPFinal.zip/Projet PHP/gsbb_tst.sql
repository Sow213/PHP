-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 27 mars 2025 à 09:11
-- Version du serveur : 8.3.0
-- Version de PHP : 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gsbb tst`
--

-- --------------------------------------------------------

--
-- Structure de la table `activités`
--

DROP TABLE IF EXISTS `activités`;
CREATE TABLE IF NOT EXISTS `activités` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `date_activité` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `activités`
--

INSERT INTO `activités` (`id`, `nom`, `description`, `date_activité`) VALUES
(1, 'Réunion de direction', 'Réunion mensuelle des cadres pour discuter des str', '2025-04-10'),
(2, 'Séminaire de formation', 'Formation sur la gestion du temps et l\'efficacité ', '2025-04-15'),
(3, 'Atelier de créativité', 'Session collaborative pour encourager l\'innovation', '2025-04-20'),
(4, 'Conférence de développement personnel', 'Conférence animée par un expert en développement p', '2025-05-05'),
(5, 'Réunion du comité scientifique', 'Réunion pour faire le point sur les recherches en ', '2025-05-10'),
(6, 'Séminaire sur la communication', 'Séminaire pour améliorer les compétences en commun', '2025-06-02'),
(7, 'Lancement de produit', 'Événement pour le lancement d\'un nouveau produit s', '2025-06-15'),
(8, 'Conférence sur la stratégie numérique', 'Conférence visant à discuter des nouvelles tendanc', '2025-07-03'),
(9, 'Formation en gestion de projet', 'Formation spécialisée pour la gestion de projets c', '2025-07-12'),
(10, 'Salon professionnel', 'Participation au salon professionnel pour rencontr', '2025-08-01');

--
-- Déclencheurs `activités`
--
DROP TRIGGER IF EXISTS `check_date_activite_insert`;
DELIMITER $$
CREATE TRIGGER `check_date_activite_insert` BEFORE INSERT ON `activités` FOR EACH ROW BEGIN
    IF NEW.date_activité < CURDATE() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Vous ne pouvez pas ajouter une activité avec une date antérieure à la date actuelle.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `comporte`
--

DROP TABLE IF EXISTS `comporte`;
CREATE TABLE IF NOT EXISTS `comporte` (
  `id_medocT` int NOT NULL AUTO_INCREMENT,
  `idC` int NOT NULL,
  PRIMARY KEY (`id_medocT`,`idC`),
  KEY `id_1` (`idC`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `comporte`
--

INSERT INTO `comporte` (`id_medocT`, `idC`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16);

-- --------------------------------------------------------

--
-- Structure de la table `contient`
--

DROP TABLE IF EXISTS `contient`;
CREATE TABLE IF NOT EXISTS `contient` (
  `id_medocC` int NOT NULL AUTO_INCREMENT,
  `id` int NOT NULL,
  PRIMARY KEY (`id_medocC`,`id`),
  KEY `id_1` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `contient`
--

INSERT INTO `contient` (`id_medocC`, `id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16);

-- --------------------------------------------------------

--
-- Structure de la table `effets_secondaires`
--

DROP TABLE IF EXISTS `effets_secondaires`;
CREATE TABLE IF NOT EXISTS `effets_secondaires` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Descriptif` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `effets_secondaires`
--

INSERT INTO `effets_secondaires` (`id`, `Descriptif`) VALUES
(1, 'Risque de lésions hépatiques en cas de surdosage.'),
(2, ' Irritation gastrique et ulcères.'),
(3, 'les nausées et les sensations vertigineuses'),
(4, 'Risque accru d\'infections gastro-intestinales.'),
(5, 'Réactions allergiques, parfois sévères.'),
(6, 'Somnolence, dépendance physique et psychique.'),
(7, 'Palpitations cardiaques, troubles du sommeil.'),
(8, 'Augmente le risque de saignement gastrique et d\'ulcères.'),
(9, 'Risque accru de douleurs musculaires et de lésions hépatiques.'),
(10, 'Constipation, dépression respiratoire.'),
(11, 'Troubles gastro-intestinaux, hypoglycémie.'),
(12, 'Insomnie, diminution de la libido.'),
(13, 'Risque accru de saignements, interactions médicamenteuses.'),
(14, 'Toux sèche, hypotension.'),
(15, 'Somnolence, dépendance.'),
(16, 'Prise de poids, augmentation de la pression artérielle.'),
(17, 'Somnolence, bouche sèche, vertiges.'),
(18, 'Maux de tête, douleurs musculaires, nausées.'),
(19, 'Sécheresse de la bouche, somnolence, fatigue.'),
(20, 'Risque de saignements, douleurs abdominales, nausées.'),
(21, 'Hypokaliémie, déshydratation, hypotension.'),
(22, 'Effets secondaires cardiovasculaires, palpitations, tremblements.'),
(23, 'Nausées, fatigue, troubles de l\'appétit.'),
(24, 'Troubles digestifs, maux d\'estomac, vertiges.'),
(25, 'Douleurs abdominales, nausées, maux de tête.'),
(26, 'Risque de diarrhée, douleurs gastriques.'),
(27, 'Éruption cutanée, troubles digestifs, vertiges.'),
(28, 'Hypotension, maux de tête, vertiges.'),
(29, 'Risque d\'allergies cutanées, somnolence.'),
(30, 'Nausées, vertiges, mal de tête.'),
(31, 'Risque d\'œdème, prise de poids, troubles digestifs.'),
(32, 'Risque d\'hypotension, vertiges, somnolence.'),
(33, 'Nausées, rétention urinaire, somnolence.'),
(34, 'Sécheresse de la bouche, vertiges, hypotension.'),
(35, 'Maux de tête, troubles de l\'humeur, troubles du sommeil.'),
(36, 'Risque d\'hypotension, vertiges, fatigue.'),
(37, 'Infections respiratoires, troubles digestifs, prise de poids.');

-- --------------------------------------------------------

--
-- Structure de la table `effets_thérapeutiques`
--

DROP TABLE IF EXISTS `effets_thérapeutiques`;
CREATE TABLE IF NOT EXISTS `effets_thérapeutiques` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Descriptif` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `effets_thérapeutiques`
--

INSERT INTO `effets_thérapeutiques` (`id`, `Descriptif`) VALUES
(1, 'Soulagement de la douleur et réduction de la fièvre.'),
(2, 'Anti-inflammatoire non stéroïdien, soulage la douleur et réduit l\'inflammation.'),
(3, 'Soulage la douleur en agissant sur des cellules nerveuses particulières de la moelle épinière et du cerveau.'),
(4, 'Réduction de la production d\'acide gastrique, traitement des ulcères gastriques et du reflux gastro-œsophagien.'),
(5, 'Antibiotique, traitement des infections bactériennes.'),
(6, 'Anxiolytique, anticonvulsivant, relaxant musculaire.'),
(7, 'Hormone thyroïdienne de remplacement, traitement de l\'hypothyroïdie.'),
(8, 'Analgésique, anti-inflammatoire, prévention des caillots sanguins.'),
(9, 'Réduction du cholestérol, prévention des maladies cardiovasculaires.'),
(10, 'Analgésique puissant, utilisé pour soulager la douleur sévère.'),
(11, 'Traitement du diabète de type 2, aide à contrôler la glycémie.'),
(12, 'Antidépresseur, traitement des troubles anxieux et de la dépression.'),
(13, 'Anticoagulant, prévention des caillots sanguins.'),
(14, 'Inhibiteur de l\'enzyme de conversion de l\'angiotensine, traitement de l\'hypertension et de l\'insuffisance cardiaque.'),
(15, 'Anxiolytique, traitement des troubles anxieux et des crises de panique.'),
(16, 'Corticostéroïde, traitement des inflammations et des réactions allergiques.'),
(17, 'Antihistaminique, traitement des allergies et des symptômes de rhume des foins.'),
(18, 'Traitement de la dysfonction érectile, amélioration du flux sanguin dans les tissus du pénis.'),
(19, 'Antihistaminique, utilisé pour traiter les symptômes des allergies comme l\'urticaires et la rhinite.'),
(20, 'Antiplaquettaire, prévention des caillots sanguins et réduction du risque d\'AVC ou de crise cardiaque.'),
(21, 'Diurétique, traitement de l\'hypertension et de l\'œdème en éliminant l\'excès de liquide du corps.'),
(22, 'Hormone thyroïdienne de remplacement, utilisée pour traiter l\'hypothyroïdie.'),
(23, 'Antidépresseur, traitement des troubles dépressifs majeurs et des troubles anxieux généralisés.'),
(24, 'Antidépresseur, traitement des troubles anxieux et des troubles obsessionnels-compulsifs (TOC).'),
(25, 'Anticoagulant, prévention des caillots sanguins en cas de fibrillation auriculaire ou de chirurgie.'),
(26, 'Inhibiteur de la pompe à protons, réduction de l\'acide gastrique pour traiter les troubles gastriques et du reflux.'),
(27, 'Anti-inflammatoire non stéroïdien (AINS), traitement de la douleur et réduction de l\'inflammation.'),
(28, 'Diurétique de l\'anse, utilisé pour traiter l\'insuffisance cardiaque et l\'hypertension artérielle.'),
(29, 'Hypnotique, utilisé pour traiter l\'insomnie et aider au sommeil.'),
(30, 'Antibiotique, traitement des infections bactériennes et parasitaires.'),
(31, 'Antihypertenseur, réduction de la pression artérielle et prévention des AVC.'),
(32, 'Relaxant musculaire, traitement de la spasticité musculaire et des troubles neurologiques.'),
(33, 'Alpha-bloquant, traitement des symptômes de l\'hyperplasie bénigne de la prostate.'),
(34, 'Antidépresseur, traitement de la dépression et des troubles anxieux.'),
(35, 'Corticostéroïde, utilisé pour réduire l\'inflammation dans diverses conditions médicales.'),
(36, 'Anticonvulsivant, traitement des crises d\'épilepsie et des troubles de l\'humeur.'),
(37, 'Corticostéroïde puissant, utilisé dans les inflammations sévères et pour le traitement des allergies.');

-- --------------------------------------------------------

--
-- Structure de la table `incompatibilité`
--

DROP TABLE IF EXISTS `incompatibilité`;
CREATE TABLE IF NOT EXISTS `incompatibilité` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_1` int NOT NULL,
  PRIMARY KEY (`id`,`id_1`),
  KEY `id_1` (`id_1`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `incompatibilité`
--

INSERT INTO `incompatibilité` (`id`, `id_1`) VALUES
(1, 2),
(1, 17),
(2, 1),
(2, 18),
(3, 4),
(3, 19),
(4, 3),
(4, 20),
(5, 6),
(5, 21),
(6, 5),
(6, 22),
(7, 8),
(7, 23),
(8, 7),
(8, 24),
(9, 10),
(9, 25),
(10, 9),
(10, 26),
(11, 12),
(11, 27),
(12, 11),
(12, 28),
(13, 14),
(13, 29),
(14, 13),
(14, 30),
(15, 16),
(15, 31),
(16, 15),
(16, 32),
(17, 18),
(18, 19),
(19, 20),
(20, 21);

-- --------------------------------------------------------

--
-- Structure de la table `medicaments`
--

DROP TABLE IF EXISTS `medicaments`;
CREATE TABLE IF NOT EXISTS `medicaments` (
  `id` int NOT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `medicaments`
--

INSERT INTO `medicaments` (`id`, `nom`, `description`) VALUES
(1, 'Paracétamol', 'Le paracétamol, aussi appelé acétaminophène, est un composé chimique utilisé comme antalgique et antipyrétique, qui figure parmi les médicaments les plus communs, utilisés et prescrits au monde.'),
(2, 'Ibuprofène', 'Ibuprofène est la dénomination commune internationale de l\'acide 2-4-propyl phénylpropanoïque. Il s\'agit de la substance active d\'un médicament AINS utilisé pour soulager les symptômes de l\'arthrite, de la dysménorrhée primaire, de la pyrexie et comme analgésique, spécialement en cas d\'inflammation.'),
(3, 'Tramadol', 'Le tramadol est un antalgique central développé par la firme allemande Grünenthal GmbH dans les années 1970. Il est classé dans la catégorie des analgésiques de niveau 2, catégorie comprenant également la codéine, les extraits d\'opium et anciennement le dextropropoxyphène.'),
(4, 'Omeprazole', 'L\'oméprazole est une substance active médicamenteuse de la famille des inhibiteurs de la pompe à protons qui réduit la sécrétion acide de l\'estomac.'),
(5, 'Amoxicilline', 'L\'amoxicilline est un antibiotique β-lactamine bactéricide de la famille des aminopénicillines indiqué dans le traitement des infections bactériennes à germes sensibles.'),
(6, 'Diazépam', 'Le diazépam est un médicament de la famille des benzodiazépines. Il possède des propriétés anxiolytiques, sédatives, amnésiantes et hypnotiques. Néanmoins, en raison de ses effets importants de somnolence résiduelle le lendemain matin, il est de moins en moins utilisé comme hypnotique en clinique.'),
(7, 'Lévothyroxine', 'La lévothyroxine, aussi connue sous le nom de L-thyroxine, T4 synthétique ou 3,5,3\',5\'-tetraiodo-L-thyronine, est une forme synthétique de la thyroxine, également utilisée comme médicament.'),
(8, 'Aspirine', 'L’acide acétylsalicylique, plus connu sous le nom commercial d’aspirine, est un anti-inflammatoire non stéroïdien. C’est la substance active de nombreux médicaments aux propriétés antalgiques, antipyrétiques et anti-inflammatoires. Il est surtout utilisé comme antiagrégant plaquettaire.'),
(9, 'Atorvastatine', 'L\'atorvastatine est un médicament de type statine utilisé pour son action hypocholestérolémiante. Cette molécule a été découverte par la société américaine Warner-Lambert et lancée en 1997.'),
(10, 'Morphine', 'La morphine est le principal alcaloïde de l\'opium, le latex du pavot somnifère. C\'est une molécule complexe utilisée en médecine comme analgésique et comme drogue pour son action euphorisante. L\'opium est utilisé en médecine depuis le IIIᵉ millénaire av.'),
(11, 'Metformine', 'La metformine est un antidiabétique oral de la famille des biguanides normoglycémiants utilisé dans le traitement du diabète de type 2. Son rôle est de diminuer l\'insulino-résistance de l\'organisme intolérant aux glucides et de diminuer la néoglucogenèse hépatique.'),
(12, 'Citalopram', 'Le citalopram, ou plus exactement le bromhydrate de citalopram, est un antidépresseur inhibiteur sélectif de la recapture de la sérotonine, il est utilisé pour le traitement de la dépression, associé ou non à des troubles de l\'humeur, et dans l\'ensemble des troubles de l\'anxiété.'),
(13, 'Warfarine', 'Le coumaphène ou warfarine est un composé organique de la famille des coumarines. C\'est une substance active de produit phytosanitaire, qui présente un effet rodenticide, avec toutefois de possibles phénomènes de résistance aux rodenticides.'),
(14, 'Lisinopril', 'Le lisinopril est un médicament inhibiteur de l\'enzyme de conversion. Il est utilisé pour traiter l\'hypertension artérielle, l\'insuffisance cardiaque et l\'après crises cardiaques. Pour l\'hypertension artérielle, il s\'agit généralement d\'un traitement de première intention.'),
(15, 'Alprazolam', 'L\'alprazolam est une benzodiazépine de la famille des triazolobenzodiazépines utilisée comme un anxiolytique d\'action rapide. En France, l\'alprazolam est la benzodiazépine la plus prescrite et est connue sous son nom commercial Xanax.'),
(16, 'Prednisone', 'La prednisone est un corticostéroïde, prodrogue métabolisée par le foie par réduction du carbonyle en hydroxyde par la 11-β-oxydoréductase hépatique, en prednisolone.'),
(17, 'Diphenhydramine', 'La diphénhydramine est un antihistaminique de première génération, utilisée principalement pour traiter les allergies, l\'insomnie et comme antiémétique. Elle a aussi des effets sédatifs et anticholinergiques.'),
(18, 'Tadalafil', 'Le tadalafil est un médicament utilisé pour traiter la dysfonction érectile et l\'hypertension artérielle pulmonaire. Il est également utilisé pour traiter les symptômes de l\'hyperplasie bénigne de la prostate.'),
(19, 'Cetirizine', 'La cétirizine est un antihistaminique de deuxième génération utilisé pour traiter les symptômes d\'allergies, comme le rhume des foins, les éruptions cutanées et l\'urticaires.'),
(20, 'Clopidogrel', 'Le clopidogrel est un médicament antiplaquettaire qui empêche la formation de caillots sanguins en inhibant l\'activation des plaquettes, et est couramment utilisé après un infarctus du myocarde ou un AVC.'),
(21, 'Hydrochlorothiazide', 'L\'hydrochlorothiazide est un diurétique thiazidique utilisé dans le traitement de l\'hypertension artérielle et de l\'œdème causé par diverses conditions, comme l\'insuffisance cardiaque congestive.'),
(22, 'Levothyroxine', 'La lévothyroxine est une forme synthétique de l\'hormone thyroïdienne thyroxine, utilisée pour traiter l\'hypothyroïdie en remplaçant l\'hormone manquante dans le corps.'),
(23, 'Duloxétine', 'La duloxétine est un inhibiteur de la recapture de la sérotonine et de la noradrénaline, utilisé pour traiter la dépression, les troubles anxieux généralisés, et les douleurs neuropathiques.'),
(24, 'Fluoxétine', 'La fluoxétine est un inhibiteur sélectif de la recapture de la sérotonine, utilisée principalement pour traiter la dépression, les troubles obsessionnels-compulsifs (TOC), et les troubles de l\'alimentation.'),
(25, 'Rivaroxaban', 'Le rivaroxaban est un anticoagulant utilisé pour prévenir et traiter les thromboses veineuses profondes et les embolies pulmonaires, et pour prévenir les AVC chez les patients atteints de fibrillation auriculaire.'),
(26, 'Esomeprazole', 'L\'ésoméprazole est un inhibiteur de la pompe à protons utilisé pour traiter les ulcères gastriques, le reflux gastro-œsophagien (RGO), et les troubles gastriques liés à l\'acide.'),
(27, 'Naproxène', 'Le naproxène est un anti-inflammatoire non stéroïdien (AINS) utilisé pour réduire l\'inflammation, la douleur et la fièvre. Il est couramment utilisé dans les traitements des douleurs musculaires et articulaires.'),
(28, 'Furosemide', 'Le furosémide est un diurétique de l\'anse utilisé pour traiter l\'hypertension artérielle et l\'œdème dû à des conditions comme l\'insuffisance cardiaque ou les troubles rénaux.'),
(29, 'Zolpidem', 'Le zolpidem est un hypnotique de la famille des imidazopéridines utilisé pour traiter les insomnies à court terme, en favorisant l\'endormissement.'),
(30, 'Métronidazole', 'Le métronidazole est un antibiotique et antiprotozoaire utilisé pour traiter des infections bactériennes et parasitaires, en particulier les infections intestinales et vaginales.'),
(31, 'Amlodipine', 'L\'amlodipine est un bloqueur des canaux calciques utilisé pour traiter l\'hypertension artérielle et les angines de poitrine.'),
(32, 'Baclofène', 'Le baclofène est un relaxant musculaire utilisé pour traiter les spasmes musculaires et la spasticité associés à des conditions comme la sclérose en plaques.'),
(33, 'Tamsulosine', 'La tamsulosine est un médicament utilisé pour traiter les symptômes de l\'hyperplasie bénigne de la prostate en relaxant les muscles de la prostate et de la vessie.'),
(34, 'Venlafaxine', 'La venlafaxine est un antidépresseur inhibiteur de la recapture de la sérotonine et de la noradrénaline, utilisé pour traiter la dépression, les troubles anxieux et les troubles paniques.'),
(35, 'Budesonide', 'Le budésonide est un corticostéroïde utilisé pour traiter l\'asthme et la maladie inflammatoire de l\'intestin en réduisant l\'inflammation dans les voies respiratoires ou dans le tractus intestinal.'),
(36, 'Carbamazépine', 'La carbamazépine est un anticonvulsivant utilisé pour traiter l\'épilepsie, les troubles de l\'humeur comme le trouble bipolaire, et les douleurs neuropathiques.'),
(37, 'Dexaméthasone', 'La dexaméthasone est un corticostéroïde puissant utilisé pour traiter des conditions inflammatoires sévères comme les allergies, l\'asthme, et certains types de cancer.');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id` int NOT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `adresse_mail` varchar(50) DEFAULT NULL,
  `profession` varchar(50) DEFAULT NULL,
  `MDP` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `nom`, `prenom`, `adresse_mail`, `profession`, `MDP`) VALUES
(1, 'Jean', 'Christophe', 'Jean.christophe@gmail.com', 'orthophoniste', 'Soleil123'),
(2, 'Andrer', 'quentin', 'quentin123@gmail.com', 'generaliste', '23'),
(3, 'Philipe', 'Baptiste', 'Baptiste.philipe@gmail.com', 'orl', 'gvojerzs'),
(4, 'admin', 'admin', 'admin@gmail.com', 'admin', 'root'),
(5, 'Rousseau', 'Marc', 'marc.rousseau@example.com', 'Chef de projet', 'mdp1415'),
(6, 'Durand', 'Isabelle', 'isabelle.durand@example.com', 'Comptable', 'mdp1617'),
(7, 'Moreau', 'Antoine', 'antoine.moreau@example.com', 'Avocat', 'mdp1819'),
(8, 'Lefevre', 'Lucie', 'lucie.lefevre@example.com', 'Infirmière', 'mdp2021'),
(9, 'Gauthier', 'Thierry', 'thierry.gauthier@example.com', 'Architecte', 'mdp2223'),
(10, 'Lemoine', 'Julien', 'julien.lemoine@example.com', 'Médecin', 'mdp2425'),
(11, 'Pires', 'Carla', 'carla.pires@example.com', 'Chercheuse', 'mdp2627'),
(12, 'Girard', 'Denis', 'denis.girard@example.com', 'Cuisinier', 'mdp2829'),
(13, 'Robert', 'Nicolas', 'nicolas.robert@example.com', 'Journaliste', 'mdp3031'),
(14, 'Blanc', 'Emilie', 'emilie.blanc@example.com', 'Consultante', 'mdp3233'),
(15, 'Hernandez', 'José', 'jose.hernandez@example.com', 'Vétérinaire', 'mdp3435'),
(16, 'Garnier', 'Marc', 'marc.garnier@example.com', 'Développeur', 'mdp3637'),
(17, 'Vidal', 'Anaïs', 'anais.vidal@example.com', 'Psychologue', 'mdp3839'),
(18, 'Carpentier', 'Henri', 'henri.carpentier@example.com', 'Professeur', 'mdp4041'),
(19, 'Fournier', 'Paul', 'paul.fournier@example.com', 'Technicien', 'mdp4243'),
(20, 'Sauvage', 'Sophie', 'sophie.sauvage@example.com', 'Photographe', 'mdp4445'),
(21, 'Benoit', 'Sophie', 'sophie.benoit@example.com', 'Designer', 'mdp1213');

--
-- Déclencheurs `utilisateurs`
--
DROP TRIGGER IF EXISTS `check_profession_insert`;
DELIMITER $$
CREATE TRIGGER `check_profession_insert` BEFORE INSERT ON `utilisateurs` FOR EACH ROW BEGIN
    IF NEW.profession = '' OR NEW.profession IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La profession ne peut pas être vide.';
    END IF;
END
$$
DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
